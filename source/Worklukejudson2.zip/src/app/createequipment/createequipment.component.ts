import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createequipment',
  templateUrl: './createequipment.component.html',
  styleUrls: ['./createequipment.component.css']
})
export class CreateequipmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
