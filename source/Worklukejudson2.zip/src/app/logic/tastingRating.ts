export class TastingRating {
    aroma: number;
    body: number;
    flavor: number;
    intesity: number;
    sweetness: number;
    aftertaste: number;
    }
