import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createtrailer',
  templateUrl: './createtrailer.component.html',
  styleUrls: ['./createtrailer.component.css']
})
export class CreatetrailerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
