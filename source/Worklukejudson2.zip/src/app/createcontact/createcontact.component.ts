import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createcontact',
  templateUrl: './createcontact.component.html',
  styleUrls: ['./createcontact.component.css']
})
export class CreatecontactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
