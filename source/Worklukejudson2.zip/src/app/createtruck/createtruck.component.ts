import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createtruck',
  templateUrl: './createtruck.component.html',
  styleUrls: ['./createtruck.component.css']
})
export class CreatetruckComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
